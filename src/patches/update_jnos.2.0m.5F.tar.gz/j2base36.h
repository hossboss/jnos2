#ifndef _J2BASE36_H
#define _J2BASE36_H
extern char *j2base36 (long);
#endif
